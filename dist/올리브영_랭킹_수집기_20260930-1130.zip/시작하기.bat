@echo off
REM ===================================================================
REM  Olive Young Ranking Collector - launcher
REM
REM  This file MUST stay ASCII-only.
REM  Windows cmd.exe parses .bat files using the system code page
REM  (cp949 on Korean Windows). Korean text - even with a UTF-8 BOM -
REM  corrupts the parser and the script fails. Korean guidance lives in
REM  the companion .txt file instead.
REM ===================================================================

setlocal
cd /d "%~dp0goods_summary\scraper"

echo.
echo ============================================================
echo    Olive Young Ranking Collector
echo ============================================================
echo.

REM ------------------------------------------------------ 1) Node.js
where node >nul 2>nul
if errorlevel 1 goto NO_NODE
for /f "tokens=*" %%v in ('node -v') do set NODEVER=%%v
echo   [ OK ] Node.js %NODEVER%

REM ------------------------------------------------------ 2) Chrome
set CHROME=
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set CHROME=1
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set CHROME=1
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set CHROME=1
if not "%CHROME%"=="1" goto NO_CHROME
echo   [ OK ] Google Chrome found

REM ------------------------------------------------------ 3) packages
if exist "node_modules\playwright\package.json" goto HAVE_PKG
echo   [SETUP] Installing required packages. Please wait...
call npm install
if errorlevel 1 goto INSTALL_FAIL
echo   [ OK ] Packages installed
:HAVE_PKG

REM ------------------------------------------------------ 4) port check
netstat -ano | findstr /r /c:":3000 .*LISTENING" >nul 2>nul
if not errorlevel 1 goto PORT_BUSY

REM ------------------------------------------------------ 5) run
echo.
echo  ------------------------------------------------------------
echo   The dashboard will open in your browser automatically.
echo   Address: http://localhost:3000
echo.
echo   * Close this black window to quit the program.
echo   * To refresh ranking data, press "Collect" in the dashboard.
echo  ------------------------------------------------------------
echo.

start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Start-Process 'http://localhost:3000'"
node server.mjs
echo.
echo   The program has stopped.
pause
goto END

REM ------------------------------------------------------ error paths
:NO_NODE
echo.
echo   [REQUIRED] Node.js is not installed.
echo.
echo   1. Open  https://nodejs.org/ko/download
echo   2. Download and install the LTS version (keep default options)
echo   3. Run this file again
echo.
for %%f in ("%~dp0*.txt") do start "" "%%f"
timeout /t 4 >nul
goto END

:NO_CHROME
echo.
echo   [REQUIRED] Google Chrome was not found.
echo.
echo   Chrome is needed to collect data from Olive Young.
echo   1. Open  https://www.google.com/chrome/
echo   2. Install Chrome
echo   3. Run this file again
echo.
for %%f in ("%~dp0*.txt") do start "" "%%f"
pause
goto END

:INSTALL_FAIL
echo.
echo   [ERROR] Package installation failed.
echo   Please check your internet connection and try again.
echo.
for %%f in ("%~dp0*.txt") do start "" "%%f"
pause
goto END

:PORT_BUSY
echo.
echo   [ERROR] Port 3000 is already in use.
echo   Another program is using it, so the dashboard cannot start.
echo.
echo   Please close that program and try again.
echo.
pause
goto END

:END
endlocal
